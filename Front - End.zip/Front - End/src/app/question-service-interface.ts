import { Observable } from 'rxjs';
import { QuestionBank } from './question-bank';

export interface QuestionServiceInterface 
{
    addQuestion(question:QuestionBank):Observable<any>;
    loadQuestions():Observable<any>;
    deleteQuestion(questionId:Number):void;
    updateQuestion(questionId:Number,question:QuestionBank):void;
}