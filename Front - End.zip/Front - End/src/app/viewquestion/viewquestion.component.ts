import { Component, OnInit } from '@angular/core';
import { QuestionBank } from '../question-bank';
import { QuestionService } from '../question.service';

@Component({
  selector: 'app-viewquestion',
  templateUrl: './viewquestion.component.html',
  styleUrls: ['./viewquestion.component.css']
})
export class ViewquestionComponent implements OnInit {

  questions : QuestionBank[]=[];
  questionUpdate : QuestionBank = new QuestionBank();

  constructor(private questionService : QuestionService) { }

  ngOnInit(): void 
  {
    this.questionService.loadQuestions().subscribe(data=>{
      this.questions=data;
    });    
  }

  deleteQuestion(questionId:Number):void
  {
    this.questionService.deleteQuestion(questionId);
    this.questionService.loadQuestions().subscribe(data=>{
      this.questions=data;
    });
  }

  updateQuestion1(question : QuestionBank):void
  {
    this.questionUpdate=question;
  }


  updateQuestion2():void
  {
    console.log(this.questionUpdate);
    this.questionService.updateQuestion(this.questionUpdate.questionId,this.questionUpdate);
    this.questionService.loadQuestions().subscribe(data=>{
      this.questions=data;
    });
  }
}