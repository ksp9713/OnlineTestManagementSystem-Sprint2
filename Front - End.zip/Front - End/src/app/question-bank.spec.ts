import { QuestionBank } from './question-bank';

describe('QuestionBank', () => {
  it('should create an instance', () => {
    expect(new QuestionBank()).toBeTruthy();
  });
});
