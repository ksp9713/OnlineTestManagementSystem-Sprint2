import { Injectable } from '@angular/core';
import { QuestionServiceInterface } from './question-service-interface';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QuestionBank } from './question-bank';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class QuestionService implements QuestionServiceInterface{


  constructor(private http:HttpClient, private route:Router) { }
  addQuestion(question: QuestionBank): Observable<any> 
  {
    console.log(JSON.stringify(question));
    return this.http.post("http://localhost:1136/question/add",question,{responseType:"text"});
  }

  loadQuestions():Observable<any> 
  {
     return this.http.get("http://localhost:1136/question/getQuestionDetails");
  }
  deleteQuestion(questionId: Number): void {
    this.http.delete("http://localhost:1136/question/deleteQuestion/"+questionId).subscribe(data=>{
      console.log(data);
    });

  }
  updateQuestion(questionId: Number, question: import("./question-bank").QuestionBank): void {
    this.http.put("http://localhost:1136/question/updateQuestion/"+questionId,question).subscribe(data=>{
      console.log(data);
    });
  }
}
