export class QuestionBank 
{
    questionId: Number;
	questionTitle : String;
	questionOptionA : String;
	questionOptionB : String;
	questionOptionC : String;
	questionOptionD : String;
	questionMarks : Number ;
	correctOptionIndex : String;
}