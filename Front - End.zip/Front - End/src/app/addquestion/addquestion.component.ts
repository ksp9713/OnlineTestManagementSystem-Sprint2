import { Component, OnInit } from '@angular/core';
import { QuestionBank } from '../question-bank';
import { QuestionService } from '../question.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {

  radioSel:any;
  radioSelected:String;
  radioSelectedString:string;

  question : QuestionBank = new QuestionBank();
  questionAdded : QuestionBank = new QuestionBank();

  constructor(private questionService : QuestionService,private route:Router) { }

  ngOnInit(): void 
  {
    this.questionAdded.questionTitle="";
    this.questionAdded.questionMarks=null;
    this.questionAdded.questionOptionA="";
    this.questionAdded.questionOptionB="";
    this.questionAdded.questionOptionC="";
    this.questionAdded.questionOptionD="";
    this.questionAdded.correctOptionIndex=null;
    this.getSelecteditem();
  }
  getSelecteditem() 
  {
    this.questionAdded.correctOptionIndex = this.radioSelected;
    //throw new Error("Method not implemented.");
  }
  /*
     addQuestion() - This method is adding question to the database.
  */
  addQuestion()
  {
    this.questionService.addQuestion(this.questionAdded).subscribe (data => {
        this.question=data
    }) ;
    this.route.navigateByUrl("/viewQuestion"); 
  }

}