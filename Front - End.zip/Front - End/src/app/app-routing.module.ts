import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewquestionComponent } from './viewquestion/viewquestion.component';
import { AddquestionComponent } from './addquestion/addquestion.component';


const routes: Routes = [
 { path: 'addQuestion', component: AddquestionComponent},
  { path: 'viewQuestion', component: ViewquestionComponent},
  { path: '', redirectTo: '/viewUser', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
